require(['../raphael'], function(Raphael){
    var paper = Raphael(0, 0, 640, 720, "container");
    //paper.circle(100, 100, 100); //example

    // Work here
});
